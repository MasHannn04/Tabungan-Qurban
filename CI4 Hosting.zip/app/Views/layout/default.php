<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= esc($pageTitle ?? 'AT-TAQWA — Tabungan Qurban Warga') ?></title>
  <meta name="description" content="Aplikasi Tabungan Qurban Warga AT-TAQWA">
  <!-- Memanggil CSS dari folder public -->
  <link rel="stylesheet" href="<?= base_url('asset/styles.css') ?>">
  <link rel="stylesheet" href="<?= base_url('styles.css') ?>">
</head>
<body class="<?= esc($bodyClass ?? 'admin-body') ?>">
  
  <?= $this->include('layout/topbar') ?>
  
  <?= $this->renderSection('sidebar') ?>

  <main>
    <?= $this->renderSection('content') ?>
  </main>

</body>
</html>
